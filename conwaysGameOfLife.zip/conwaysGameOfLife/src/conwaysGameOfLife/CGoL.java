package conwaysGameOfLife;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CGoL extends JFrame implements Runnable,MouseListener,MouseMotionListener 
{
	private BufferStrategy strategy;
	private Graphics offscreenBuffer;
	private boolean gameState[][][] = new boolean[40][40][2];
	private int gameStateFrontBuffer=0;
	private boolean isGameRunning=false;
	private boolean isInitialised=false;
	
	public CGoL()
	{
		Dimension screensize=java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		int x= screensize.width/2;
		int y= screensize.height/2;
		setBounds(x,y,800,800);
		setVisible(true);
		this.setTitle("Conways Game of Life");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		createBufferStrategy(2);
		strategy=getBufferStrategy();
		offscreenBuffer=strategy.getDrawGraphics();
		
		addMouseListener(this);
		addMouseMotionListener(this);
		
		for(x=0;x<40;x++)
		{
			for(y=0;y<40;y++)
			{
				gameState[x][y][0]=gameState[x][y][1]=false;
			}
		}
		
		Thread t =new Thread(this);
		t.start();
		
		isInitialised=true;
		
	}

	@Override
	public void mouseDragged(MouseEvent e) 
	{
		int x=e.getX()/20;
		int y=e.getY()/20;
		gameState[x][y][gameStateFrontBuffer]=!gameState[x][y][gameStateFrontBuffer];
		this.repaint();
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) 
	{
		if(!isGameRunning)
		{
			int x=e.getX();
			int y=e.getY();
			if(x>=15 && x<=85 && y>=40 && y<=70)
			{
				isGameRunning=true;
				return;
			}
			if(x>=115 && x<=215 && y>=40 && y<=70)
			{
				RandomiseGameState();
				return;
			}
			if(x>=315 && x<=385 && y>=40 && y<=70)
			{
				load();
				return;
			}
			if(x>=415 && x<=485 && y>=40 && y<=70)
			{
				save();
			}
		}
		int x=e.getX()/20;
		int y=e.getY()/20;
		gameState[x][y][gameStateFrontBuffer]=!gameState[x][y][gameStateFrontBuffer];
		this.repaint();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run() 
	{
		while(true)
		{
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}
			if(isGameRunning)
			{
				doOneEpochOfGame();
			}
			this.repaint();
		}
		
	}
	public void save()
	{
		String outputText="";
		String filename = "//Users//colette//Desktop//lifegame.txt";
		for(int x=0;x<40;x++)
		{
			for(int y=0;y<40;y++)
			{
				if(gameState[x][y][gameStateFrontBuffer])
				{
					outputText+="1";
				}
				else
				{
					outputText+="0";
				}
			}
		}
		try 
		{
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			writer.write(outputText);
			writer.close();
			
		}
		catch(IOException e)
		{
			
		}
		
		
	}
	public void load()
	{
		String filename = "//Users//colette//Desktop//lifegame.txt";
		String textInput=null;
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			textInput=reader.readLine();
			reader.close();
			
		}
		catch(IOException e)
		{
			
		}
		
			int i =0;
			for(int x=0;x<40;x++)
			{
				for(int y=0; y<40; y++)
				{
					char c = textInput.charAt(i);
					if(c=='0')
					{
					
						gameState[x][y][gameStateFrontBuffer]=false;
					}
					else
					{
						gameState[x][y][gameStateFrontBuffer]=true;
					}
					i++;
				}
			}
		

	}
	public void doOneEpochOfGame()
	{
		int front = gameStateFrontBuffer;
		int back = (front+1)%2;
		
		for(int x =0;x<40;x++)
		{
			for(int y=0;y<40;y++)
			{
				int liveNeighbours=0;
				for(int xx=-1;xx<=1;xx++)
				{
					for(int yy=-1;yy<=1;yy++)
					{
						if(xx!=0||yy!=0)
						{
							int xxx=x+xx;
							if(xxx<0)
							{
								xxx=39;
							}
							else if(xxx>39)
							{
								xxx=0;
							}
							int yyy = y+yy;
							if(yyy<0)
							{
								yyy=39;
							}
							else if(yyy>39)
							{
								yyy=0;
							}
							if(gameState[xxx][yyy][front])
							{
								liveNeighbours++;
							}
						}
					}
				}
				if(gameState[x][y][front])
				{
					if(liveNeighbours<2)
					{
						gameState[x][y][back]=false;
					}
					else if(liveNeighbours<4)
					{
						gameState[x][y][back]=true;
					}
					else
					{
						gameState[x][y][back]=false;
					}
				}
				else
				{
					if(liveNeighbours==3)
					{
						gameState[x][y][back]=true;
					}
					else
					{
						gameState[x][y][back]=false;
					}
				}
			}
		}
		gameStateFrontBuffer = back;
	}
	private void RandomiseGameState()
	{
		for(int x=0;x<40;x++)
		{
			for(int y=0;y<40;y++)
			{
				gameState[x][y][gameStateFrontBuffer]=(Math.random()<0.25);
			}
		}
	}
	
	public void paint(Graphics g)
	{
		if(!isInitialised)
		{
			return;
		}
		
		g=offscreenBuffer;
		
		g.setColor(Color.BLACK);
		g.fillRect(0,0, 800, 800);
		
		g.setColor(Color.WHITE);
		for(int x=0;x<40;x++)
		{
			for(int y=0;y<40;y++)
			{
				if(gameState[x][y][gameStateFrontBuffer])
				{
					g.fillRect(x*20, y*20, 20, 20);
				}
			}
				
		}
		if(!isGameRunning)
		{
			g.setColor(Color.GREEN);
			g.fillRect(15, 40, 70, 30);
			g.fillRect(115, 40, 100, 30);
			g.fillRect(315,40, 70, 30);
			g.fillRect(415,40, 70, 30);
			g.setFont(new Font("Times",Font.PLAIN,24));
			g.setColor(Color.BLACK);
			g.drawString("Start", 22, 62);
			g.drawString("Random", 122, 62);
			g.drawString("Load", 322, 62);
			g.drawString("Save", 422, 62);
			
			
		}
		strategy.show();
	}
	
	
	public static void main(String[]args)
	{
		 CGoL c = new CGoL();
	}
		
}


import java.awt.Image;


public class Bullet extends Sprite2D
{

	public Bullet(Image i1, Image i2) 
	{
		super(i1, i2);
		
		
	}
	public boolean move(Alien[] a)
	{
		
			  y-=5;
		
		for(Alien en : a)
		{
			if(en.isAlive&&this.isAlive)
			{
			if(((en.x<this.x && en.x+en.myImage1.getWidth(null)>this.x)||(this.x <en.x && this.x+myImage1.getWidth(null)>en.x))
					&&(((en.y<this.y && en.y+en.myImage1.getHeight(null)>this.y)||(this.y<en.y && this.y+myImage1.getHeight(null)>en.y))))
			{
				en.isAlive=false;
				this.isAlive=false;
				InvadersApp.score++;
				InvadersApp.aliensAlive--;
			}
			}
		}
		return false;
	}

}

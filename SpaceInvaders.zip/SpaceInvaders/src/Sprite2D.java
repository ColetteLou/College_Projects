import java.awt.Graphics;
import java.awt.Image;

public class Sprite2D 
{
	protected double x,y;
	protected Image myImage1;
	protected Image myImage2;
	protected int framesDrawn=0;
	protected static int winWidth;
	protected boolean isAlive =true;
	public Sprite2D(Image i1,Image i2)
	{
		myImage1=i1;
		myImage2=i2;
	}
	
	public void setPosition(double xx,double yy)
	{
		x=xx;
		y=yy;
	}
	public void paint(Graphics g)
	{
		framesDrawn++;
		if ( framesDrawn%100<50)
		{
			g.drawImage(myImage1, (int)x, (int)y, null); 
		}
		else
		{
			g.drawImage(myImage2,(int)x, (int)y, null);
		}
	}
	
	public static void setWinWidth(int w) 
	{
		winWidth=w;
	}

}

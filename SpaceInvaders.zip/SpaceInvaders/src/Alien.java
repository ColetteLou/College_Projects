import java.awt.Graphics;
import java.awt.Image;

public class Alien extends Sprite2D
{
	protected static double xSpeed=0;
	
	public Alien(Image i1,Image i2)
	{
		super(i1,i2);
		

	}
	public boolean move()
	{
		x+=xSpeed;
		if(isAlive) {
		if(x<=0||x>=(winWidth-myImage1.getWidth(null)))
		{
			return true;
		}
		else
		{
			return false;
		}
		}
		return false;
		
	}
	public static void setFleetSpeed(double dx)
	{
		xSpeed=dx;
	}
	public static void reverseDirection()
	{
		xSpeed=-xSpeed;
	}
	public void jumpDownwards()
	{
		y+=20;
	}

}

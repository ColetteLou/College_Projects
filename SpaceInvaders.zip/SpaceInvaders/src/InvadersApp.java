import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.*;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.*;



public class InvadersApp extends  JFrame implements Runnable, KeyListener
{
	private static final Dimension WindowSize = new Dimension(800,600);
	private static final int ALIENS = 30;
	private static String workingDirectory;
	private Alien[] AliensArray = new Alien[ALIENS];
	private Ship PlayerShip;
	private boolean isInitialised = false;
	private BufferStrategy strategy;
	private Graphics offScreenGraphics;
	private boolean alienDirectionReversalNeeded;
	private ArrayList <Bullet> bulletlist=new ArrayList<Bullet>();
	private Image bulletImage;
	private boolean gameInProgress;
	private boolean gameOver;
	private Image gameOverIMG;
	private Image startIMG;
	private int HiScore=0;
	public static int score=0;
	public static int aliensAlive=30;
	
	
	
	

	
	public InvadersApp() 
	{
		this.setTitle("SpaceInvaders");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Dimension screensize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		int x = screensize.width/2 - WindowSize.width/2;
		int y = screensize.height/2 - WindowSize.height/2;
		setBounds(x, y, WindowSize.width, WindowSize.height);
		setVisible(true);
		
		ImageIcon icon = new ImageIcon(workingDirectory +"//game_over.png");
		gameOverIMG = icon.getImage();
		ImageIcon icon1 = new ImageIcon(workingDirectory +"//start_game.png");
		startIMG = icon1.getImage();

		addKeyListener(this);

		Sprite2D.setWinWidth(WindowSize.width);
		gameInProgress=false;
		gameOver=false;
		
		
		
		Thread t1 = new Thread(this);
		t1.start();
	
		
		createBufferStrategy(2);
		strategy=getBufferStrategy();
		offScreenGraphics=strategy.getDrawGraphics();
		isInitialised = true;
		
		
	}
	

	@Override
	public void run() 
	{
		while(true)
		{
			if(gameInProgress)
			{
				try 
				{
					Thread.sleep(20);
				} 
				catch (InterruptedException e) 
				{
				}
				
					alienDirectionReversalNeeded =false;
					for(int i=0;i<ALIENS;i++)
					{
            				if(AliensArray[i].move())
            				{
            					alienDirectionReversalNeeded=true;
            				}
					}
					if(alienDirectionReversalNeeded)
            			{
            				Alien.reverseDirection();
            				for(int i=0;i<ALIENS; i++)
            				{
            					AliensArray[i].jumpDownwards();
            				}
            			}
            			for(Bullet b : bulletlist)
            			{
            				b.move(AliensArray);
            	
            			}
            			if(aliensAlive==0)
            			{
            				
            				startNewWave();
           
            			}
            			
            			PlayerShip.move(AliensArray);
            			gameInProgress=PlayerShip.move(AliensArray);
            			gameOver=!(PlayerShip.move(AliensArray));
            			this.repaint();
				}
			else
			{
				try 
				{
					Thread.sleep(20);
				} 
				catch (InterruptedException e) 
				{
				}
				this.repaint();
			}
		}
			
		}
		
	

	@Override
	public void keyTyped(KeyEvent e) 
	{
		
		
		
	}

	@Override
	public void keyPressed(KeyEvent e) 
	{
		if(gameInProgress)
		{
			if(e.getKeyCode()==KeyEvent.VK_LEFT)
			{
				PlayerShip.setXSpeed(-4.0);
			}
			else if(e.getKeyCode()==KeyEvent.VK_RIGHT)
			{
			
				PlayerShip.setXSpeed(4.0);
			
			}
			else if(e.getKeyCode()==KeyEvent.VK_SPACE)
			{
				this.shootBullet();
			}
		}
		else if(!gameInProgress &&!gameOver)
		{
			int key =e.getKeyCode();
			if(key!=0)
			{
				startNewGame();
			}

		}
		else if(gameOver)
		{
			int key =e.getKeyCode();
			if(key!=0)
			{
				startNewGame();
				score=0;
			}
			
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) 
	{
		if(e.getKeyCode()==KeyEvent.VK_RIGHT||e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			PlayerShip.setXSpeed(0.0);
		}
		
		
	}
	
	public void paint(Graphics g)
	{
		if(isInitialised)
		{
			g = offScreenGraphics;
			
			if(!gameInProgress && !gameOver)
			{
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, WindowSize.width, WindowSize.height);
				g.drawImage(startIMG, 0, 0, null);
				
			
			}
			else if(gameInProgress &&!gameOver)
			{
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, WindowSize.width, WindowSize.height);
				g.setColor(Color.WHITE);
				
				String scoreDisp = "SCORE:"+ Integer.toString(score*10);
				String hiScore = "HI-SCORE:"+ Integer.toString(getHiScore(score)*10);
				g.drawString(scoreDisp, 200,50);
				g.drawString(hiScore, 400,50);
				
				for(Alien s : AliensArray)
				{
					if(s.isAlive)
					{
						s.paint(g);
					}
				}
			
				Iterator <Bullet> iterator = bulletlist.iterator();
				while(iterator.hasNext())
				{
					Bullet b = iterator.next();
					if(b.isAlive)
					{
						b.paint(g);
					}
				}
			
			
				PlayerShip.paint(g);
			}
			else if(gameOver)
			{
				g.setColor(Color.BLACK);
				g.fillRect(0, 0, WindowSize.width, WindowSize.height);
				g.drawImage(gameOverIMG, 0, 0, null);
				
			}
				
			strategy.show();
				
		}
	}
		
	public void shootBullet()
	{
		Bullet b = new Bullet(bulletImage,bulletImage);
		b.setPosition(PlayerShip.x+54/2, PlayerShip.y);
		bulletlist.add(b);
		
	}
	public void startNewGame()
	{
		ImageIcon icon = new ImageIcon(workingDirectory +"//alien_ship_1.png"); 
		Image alienImage1 = icon.getImage();
		
		ImageIcon icon2 = new ImageIcon(workingDirectory +"//alien_ship_2.png"); 
		Image alienImage2 = icon2.getImage();
		
		ImageIcon icon1 = new ImageIcon(workingDirectory +"//player_ship.png");
		Image shipImage=icon1.getImage();
		
		ImageIcon icon3 = new ImageIcon(workingDirectory +"//bullet.png");
		bulletImage = icon3.getImage();
		
		for(int i =0; i<ALIENS; i++)
		{
			AliensArray[i]= new Alien(alienImage1,alienImage2);
			double xx = (i%5)*80 +70;
			double yy = (i/5)*40 +50;
			AliensArray[i].setPosition(xx,yy);
		}
		Alien.setFleetSpeed(2.0);
		
		
		
		PlayerShip = new Ship(shipImage,shipImage);
		PlayerShip.setPosition(300.00,550.00);
		
		gameInProgress=true;
		
		
		
	}
	
	public void startNewWave() 
	{
		aliensAlive=30;
		for(int i =0; i<ALIENS; i++)
		{
			Alien a = AliensArray[i];
			a.isAlive=true;
			double xx = (i%5)*80 +70;
			double yy = (i/5)*40 +50;
			a.setPosition(xx,yy);
		}
		double faster = Alien.xSpeed+1;
		Alien.setFleetSpeed(faster);
	}
	
	
	public static void main(String [] args)
	{
		workingDirectory = System.getProperty("user.dir"); 
		//System.out.println("Working Directory = " + workingDirectory);
	
		InvadersApp a1 = new InvadersApp();
		
	}
	public int getHiScore(int currScore)
	{
		if(HiScore<currScore)
		{
			HiScore=currScore;
			
		}
		return HiScore;
		
	}

}

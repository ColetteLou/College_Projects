import java.awt.Image;

public class Ship extends Sprite2D 
{
	private double xSpeed;
	
	public Ship(Image i1,Image i2)
	{
		super(i1,i2);
	}
	public void setXSpeed(double dx)
	{
		xSpeed=dx;
	}
	public boolean move(Alien[] a)
	{
			x+=xSpeed;
			if(x<=0)
			{
				x=0;
				xSpeed=0;
			}
			else if (x>=(winWidth-myImage1.getWidth(null)))
			{
				x= winWidth-myImage1.getWidth(null);
				xSpeed=0;
			}
			for(Alien en : a)
			{
				if(en.isAlive)
				{
					if(((en.x<this.x && en.x+en.myImage1.getWidth(null)>this.x)||(this.x <en.x && this.x+myImage1.getWidth(null)>en.x))
					&&(((en.y<this.y && en.y+en.myImage1.getHeight(null)>this.y)||(this.y<en.y && this.y+myImage1.getHeight(null)>en.y))))
					{
					
						return false;
					}
				}
			
			}
			return true;
	}
	
	
	
}
